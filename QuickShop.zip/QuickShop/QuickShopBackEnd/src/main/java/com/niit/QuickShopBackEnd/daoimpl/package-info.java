/**
 * 
 */
/**
 * @author Acer
 *
 */
package com.niit.QuickShopBackEnd.daoimpl;